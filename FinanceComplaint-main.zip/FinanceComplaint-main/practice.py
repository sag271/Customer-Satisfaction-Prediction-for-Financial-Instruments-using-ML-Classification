from FinancialComplaints.pipeline.training_pipeline import Pipeline
from FinancialComplaints.config.configuration import Configuration

pipeline = Pipeline()
pipeline.run()