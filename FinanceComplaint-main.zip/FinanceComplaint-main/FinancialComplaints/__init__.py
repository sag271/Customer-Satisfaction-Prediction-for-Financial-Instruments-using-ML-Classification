from dotenv import load_dotenv 

print(f"Reading environment variables")
load_dotenv()